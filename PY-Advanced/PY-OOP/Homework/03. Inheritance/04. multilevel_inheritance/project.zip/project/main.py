from project.sports_car import SportsCar

gtr = SportsCar()
print(gtr.drive())
print(gtr.move())
