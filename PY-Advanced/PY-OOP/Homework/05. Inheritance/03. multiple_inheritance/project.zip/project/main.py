from project.teacher import Teacher

teacher_one = Teacher()
print(teacher_one.teach())
print(teacher_one.get_fired())
print(teacher_one.sleep())
